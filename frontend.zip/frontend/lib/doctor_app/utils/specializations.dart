class SpecializationsList {
  static const List<String> list = [
    "Cardiologist",
    "Dermatologist",
    "Neurologist",
    "Orthopedic Surgeon",
    "Psychiatrist",
    "Radiologist",
    "General Physician",
    "Pediatrician",
    "ENT Specialist",
    "Gynecologist",
    "Dentist",
    "Oncologist",
    "Gastroenterologist",
    "Nephrologist",
    "Pulmonologist",
  ];
}
