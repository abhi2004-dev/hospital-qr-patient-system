import 'package:flutter/material.dart';

class PatientRegistrationStep2 extends StatefulWidget {
  final String name;
  final String dob;
  final String phone;
  final String bloodGroup;
  final List<String> allergies;
  final String currentMeds;
  final String pastSurgeries;
  final String insuranceProvider;
  final String guardianName;
  final String guardianPhone;
  final String guardianRelation;

  const PatientRegistrationStep2({
    super.key,
    required this.name,
    required this.dob,
    required this.phone,
    required this.bloodGroup,
    required this.allergies,
    required this.currentMeds,
    required this.pastSurgeries,
    required this.insuranceProvider,
    required this.guardianName,
    required this.guardianPhone,
    required this.guardianRelation,
  });

  @override
  State<PatientRegistrationStep2> createState() =>
      _PatientRegistrationStep2State();
}

class _PatientRegistrationStep2State extends State<PatientRegistrationStep2> {
  final TextEditingController passwordCtrl = TextEditingController();
  final TextEditingController confirmCtrl = TextEditingController();

  bool passVisible = false;
  bool confirmVisible = false;

  void _submit() {
    if (passwordCtrl.text.isEmpty || confirmCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter all fields")),
      );
      return;
    }

    if (passwordCtrl.text != confirmCtrl.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Passwords do not match")),
      );
      return;
    }

    // TODO — Call backend API
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Patient Registered successfully!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFFBF8),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(color: Colors.black),
        title: const Text("Patient Registration - Step 2"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: passwordCtrl,
              obscureText: !passVisible,
              decoration: InputDecoration(
                labelText: "Password",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
                suffixIcon: IconButton(
                  icon: Icon(
                      passVisible ? Icons.visibility : Icons.visibility_off),
                  onPressed: () =>
                      setState(() => passVisible = !passVisible),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: confirmCtrl,
              obscureText: !confirmVisible,
              decoration: InputDecoration(
                labelText: "Confirm Password",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
                suffixIcon: IconButton(
                  icon: Icon(confirmVisible
                      ? Icons.visibility
                      : Icons.visibility_off),
                  onPressed: () =>
                      setState(() => confirmVisible = !confirmVisible),
                ),
              ),
            ),
            const SizedBox(height: 28),
            ElevatedButton(
              onPressed: _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black87,
                padding: const EdgeInsets.symmetric(
                    horizontal: 40, vertical: 14),
              ),
              child: const Text(
                "Register",
                style: TextStyle(fontSize: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}
